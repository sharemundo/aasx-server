D   Ihre CAD Daten vom 16.06.2020 von Festo:

    Sehr geehrter Kunde,
    
    im Anhang finden Sie folgende Datei unseres 2D/3D-CAD Portals powered by CADENAS:
    
	Identifikationsnummer: 4828466 DPDM-Q-32-10-PA 
    
    STEP, 4828466 DPDM-Q-32-10-PA---(0), 4828466_DPDM-Q-32-10-PA.stp
    
    Bitte beachten Sie auch die Download Vereinbarung unter:
    http://www.cadenas.de/nutzungsbedingungen-3d-cad-modelle
    
    Mit freundlichen Gr��en
    
    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
    